All icons are official sanrio material with minor editing done by me, except for the hello kitty petscii icon, which was done by me from scratch.

Instructions:
for the .ico images, simply right click the desktop shortcut, and go to properties > change icon, except for the recycle bin, which you customize in your desktop personalization settings. sanrio_start.png is meant to be used with open-shell as a start menu replacement button, and is scaled to fit on the windows 11 taskbar.


-- greggy, 2024